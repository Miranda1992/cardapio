package com.example.myapplication.model;

public class Food {
    int imgFood;
    String foodName;
    String foodDescripption;
    String price;

    public int getImgFood() {
        return imgFood;
    }

    public void setImgFood(int imgFood) {
        this.imgFood = imgFood;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodDescripption() {
        return foodDescripption;
    }

    public void setFoodDescripption(String foodDescripption) {
        this.foodDescripption = foodDescripption;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
