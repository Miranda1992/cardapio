package com.example.myapplication.Adapter;

import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.WindowDecorActionBar;

public class FoodItemBinding {
    public View imgFood;
    public WindowDecorActionBar.TabImpl txtNomeFood;
    public WindowDecorActionBar.TabImpl txtDescripption;
    public WindowDecorActionBar.TabImpl txtPrice;

    public static FoodItemBinding inflate(LayoutInflater from) {
    }

    public View getRoot() {
    }
}
